
#include<rclcpp/rclcpp.hpp>
#include<hero_msgs/msg/auto_aim.hpp>
#include<CommPort.h>
#include "std_msgs/msg/int32.hpp"
#include <geometry_msgs/msg/quaternion.hpp>

using namespace std::chrono_literals;

class ContactNode : public rclcpp::Node
{
    public:
        ContactNode():Node("contact")
        {
        comm.Start();
        _mode_pub_ = this->create_publisher<std_msgs::msg::Int32>("/auto/mode", 10);
        quaternion_pub_ = this->create_publisher<geometry_msgs::msg::Quaternion>("/quaternion", 10);
        _gamestatus_sub_ = this->create_subscription<hero_msgs::msg::AutoAIM>("/autoaim/target", 1000, std::bind(&ContactNode::autoaim_callback, this, std::placeholders::_1));
        __timer__ = this->create_wall_timer(100ms, std::bind(&ContactNode::timer_callback, this));
        }

        void autoaim_callback(const hero_msgs::msg::AutoAIM::SharedPtr msg)
        {
            TxPacket packet;
            packet[0] = 0x5A;
            packet[1] = 1;
            packet[2] = 1;
            union {
                float actual;
                uint8_t raw[4];
            } tx_x{}, tx_y{};

            float x_offset = 0.0985;
            float y_offset = -0.013;

            tx_x.actual = pitch_temp + msg->pitch + x_offset;
            tx_y.actual = yaw_temp + msg->yaw + y_offset;
            RCLCPP_INFO(this->get_logger(),"send delta pitch is %f,send actual pitch is %f",msg->pitch,tx_x.actual);
            RCLCPP_INFO(this->get_logger(),"send delta yaw is %f,send actual yaw is %f",msg->yaw,tx_y.actual);

            for (int i = 0; i < 4; i++) {
                packet[2 + i] = tx_x.raw[i];  // x
                packet[6 + i] = tx_y.raw[i];  // y
            }
            Crc8Append(&packet, 12);
            //printf("pitch %.2f yaw %.2f id %d cmd %d  time %.3f  \n", robotcmd.pitch_angle, robotcmd.yaw_angle, robotcmd.target_id, packet[1], robotstatus.timestamp);
            comm.Write(&packet, 12, true);
        }

        void timer_callback()
        {
              pitch_temp = comm.get_Pitch();
        yaw_temp = comm.get_Yaw();
        // std::cout<<pitch_temp<<std::endl;
        // std::cout<<yaw_temp<<std::endl;
        auto q = comm.getQuaternion();
        geometry_msgs::msg::Quaternion quaternion_msg;
        quaternion_msg.x = q[0];
        quaternion_msg.y = q[1];
        quaternion_msg.z = q[2];
        quaternion_msg.w = q[3];   //写到打符pre

        quaternion_pub_->publish(quaternion_msg);
        RCLCPP_INFO(this->get_logger(), "Published quaternion x: %f, y: %f, z: %f, w: %f", q[0], q[1], q[2], q[3]);
       
        auto msg = std_msgs::msg::Int32();
        msg.data = comm.get_mode();  // 可以替换为任何你想要的整数值
        // 发布消息
        _mode_pub_->publish(msg);
        RCLCPP_INFO(this->get_logger(), "Published integer: %d", msg.data);
        }
        
  private:
    rclcpp::Subscription<gary_msgs::msg::AutoAIM>::SharedPtr _gamestatus_sub_;
    rclcpp::Publisher<geometry_msgs::msg::Quaternion>::SharedPtr quaternion_pub_;
    rclcpp::Publisher<std_msgs::msg::Int32>::SharedPtr _mode_pub_;
    rclcpp::TimerBase::SharedPtr __timer__;
    CommPort comm;
    float pitch_temp{};
    float yaw_temp{};
};

int main(int argc, char** argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<ContactNode>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}


